function controlaSeries(chart) {
  var valor;
  if (parSeriesDefault == 'N') {
    valor = false;
  } else {
    valor = true;
  }

  // Desabilita todas as Series - Menos a primeira
  var firstSeries = chart.data.dimensions('series').min();
  var hideDatums = chart.data.datums(null, {
    where: function(d) {
      return d.atoms.series !== firstSeries;
    }
  });

  pvc.data.Data.setVisible(hideDatums, valor);

  chart.render(true, true, false);
}

function formata_valor(valor, tipo) {
  // Substitui todas as virgulas por ponto
  valor = valor.toString();
  valor = valor.replace(/,/g, '.');

  // Se passar I indica formatacao de Inteiro e não usa virgula (Ex: 999.600)

  if (tipo != 'I') {
    // Nao é inteiro - usa a virgula (Ex: 999.600,99)
    // Substitui o ultimo ponto por virgula
    pos = valor.lastIndexOf('.');
    valor = valor.substring(0, pos) + ',' + valor.substring(pos + 1);
  }

  return valor;
}

function activateThisColumn() {
  var form = document.getElementById('formcontainer');
  //var rects = document.getElementById("Terceiro_Mostrador").getClientRects(); //This returns a set of rectangles representing the element
  //var rect = rects[0]; //There is usually only 1 rectangle

  // show the form!
  //form.style.left = rect.left + "px";
  form.style.display = 'block';
  //alert("Clicked on: " + parEmpresa);
}

function hideTheForm() {
  // get the form
  var form = document.getElementById('formcontainer');
  // hide the form
  form.style.display = 'none';
}

function controlaParametros(parParametrosDefault, Dashboards) {
  hoje = new Date();
  diaAtual = hoje.getDate();
  mesAtual = hoje.getMonth();
  anoAtual = hoje.getFullYear();
  if (diaAtual < 10) {
    diaAtual = '0' + diaAtual;
  }
  if (anoAtual < 2000) {
    anoAtual = '19' + anoAtual;
  }
  primDiaAtual = 1;
  ultiDiaAtual = new Date(anoAtual, mesAtual + 1, 0).getDate();
  primDiaAnter = 1;
  ultiDiaAnter = new Date(anoAtual, mesAtual, 0).getDate();

  for (var i = 0; i < parParametrosDefault.length; i++) {
    switch (parParametrosDefault[i][1]) {
      case 'DATA_ATUAL':
        Dashboards.fireChange(
          parParametrosDefault[i][0],
          diaAtual + '/' + (mesAtual + 1) + '/' + anoAtual
        );
        break;
      case 'PRIM_DIA_MES_ATUAL':
        Dashboards.fireChange(
          parParametrosDefault[i][0],
          primDiaAtual + '/' + (mesAtual + 1) + '/' + anoAtual
        );
        break;
      case 'ULTIMO_DIA_MES_ATUAL':
        Dashboards.fireChange(
          parParametrosDefault[i][0],
          ultiDiaAtual + '/' + (mesAtual + 1) + '/' + anoAtual
        );
        break;
      case 'PRIM_DIA_MES_ANTERIOR':
        Dashboards.fireChange(
          parParametrosDefault[i][0],
          primDiaAnter + '/' + mesAtual + '/' + anoAtual
        );
        break;
      case 'ULTIMO_DIA_MES_ANTERIOR':
        Dashboards.fireChange(
          parParametrosDefault[i][0],
          ultiDiaAnter + '/' + mesAtual + '/' + anoAtual
        );
        break;
      default:
        Dashboards.fireChange(
          parParametrosDefault[i][0],
          parParametrosDefault[i][1]
        );
        break;
    }
  }
  Dashboards.update();
}

function AbrirUrl(url) {
  var url_servidor = 'http://' + document.location.host + '/';

  window.open(url_servidor + url);
}

function AbrirFancy(url) {
  $.fancybox({
    type: 'iframe',
    href: 'http://' + document.location.host + '/' + url,
    width: $(window).width(),
    height: $(window).height()
  });
}

/** start addIn numericBR **/
var numericBR = {
  name: 'numericBR',
  label: 'Numeric BR',
  defaults: {
    decimal: true,
    textFormat: function(v, st, opt) {
      var nStr = v.toFixed(2) + '';
      x = nStr.split('.');
      x1 = x[0];
      x2 = x.length > 1 ? ',' + x[1] : '';
      var rgx = /(\d+)(\d{3})/;
      while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + '.' + '$2');
      }
      return x1 + (opt.decimal ? x2 : '');
    }
  },
  init: function() {
    $.fn.dataTableExt.oSort[this.name + '-asc'] =
      $.fn.dataTableExt.oSort['numeric-asc'];
    $.fn.dataTableExt.oSort[this.name + '-desc'] =
      $.fn.dataTableExt.oSort['numeric-desc'];
  },

  implementation: function(tgt, st, opt) {
    var text = opt.textFormat.call(this, st.value, st, opt);
    $(tgt)
      .empty()
      .append("<span style='text-align:right;'>" + text + '</span>');
  }
};
Dashboards.registerAddIn('Table', 'colType', new AddIn(numericBR));
/** end addIn numericBR **/

/** start addIn integerBR **/
var integerBR = {
  name: 'integerBR',
  label: 'Integer BR',
  defaults: {
    decimal: false,
    textFormat: function(v, st, opt) {
      var nStr = v.toFixed(2) + '';
      x = nStr.split('.');
      x1 = x[0];
      x2 = x.length > 1 ? ',' + x[1] : '';
      var rgx = /(\d+)(\d{3})/;
      while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + '.' + '$2');
      }
      return x1 + (opt.decimal ? x2 : '');
    }
  },
  init: function() {
    $.fn.dataTableExt.oSort[this.name + '-asc'] =
      $.fn.dataTableExt.oSort['numeric-asc'];
    $.fn.dataTableExt.oSort[this.name + '-desc'] =
      $.fn.dataTableExt.oSort['numeric-desc'];
  },

  implementation: function(tgt, st, opt) {
    var text = opt.textFormat.call(this, st.value, st, opt);
    $(tgt)
      .empty()
      .append("<span style='text-align:right;'>" + text + '</span>');
  }
};
Dashboards.registerAddIn('Table', 'colType', new AddIn(integerBR));
/** end addIn integerBR **/

/** Funçao para Alimentar o logo  dos Grupos economicos dinamicamente **/
function buscaLogo() {
  var nameLogo = parLogo !== 'null.png' ? parLogo : 'SemLogo.png';
  var url =
    '../../../api/repos/pamenu/resources/web-components/logos/' + nameLogo;

  var http = new XMLHttpRequest();
  http.open('HEAD', url, false);
  http.send();

  if (http.status == 500 || http.status == 404) {
    url =
      '../../../api/repos/pamenu/resources/web-components/logos/SemLogo.png';
  }

  var imagem = document.createElement('img');
  imagem.src = url;
  imagem.style.width = '96px';
  imagem.style.height = '64px';

  document.getElementById('Logo').appendChild(imagem);
}
/** fim buscaLogo **/

/**
 * Monta info pra Dashboards e gráficos
 */
function infosToDash(data) {
  var infos = [];

  $(data.resultset).each(function(i, rs) {
    var info = {};
    $(rs).each(function(j, r) {
      info[data.metadata[j].colName] = r;
    });
    infos.push(info);
  });

  $(infos).each(function(i, inf) {
    if (isDashboard(inf)) {
      buildInfoDash(inf);
    }

    if (isGrafico(inf)) {
      buildInfoGrafico(inf);
    }
  });

  function isDashboard(inf) {
    return (
      inf.dashboard !== undefined &&
      inf.mensagem !== undefined &&
      (inf.grafico == null || inf.grafico == '' || inf.grafico == '(NULL)')
    );
  }

  function isGrafico(inf) {
    return inf.grafico !== undefined && inf.mensagem !== undefined;
  }

  function buildInfoDash(inf) {
    if (infoDashboardAlreadyExist()) {
      var $dash = $('#infoDash');

      $dash.append(
        '<a type="button" class="glyphicon glyphicon-info-sign" style="font-size:18px;" data-toggle="modal" href=".Dashboard"></a>'
      );
      $dash.append(
        buildModal('Dashboard', getTitelDashboard(inf.titulo), inf.mensagem)
      );
    }
  }

  function infoDashboardAlreadyExist() {
    return (
      $('#infoDash')
        .children("div[class^='modal']")
        .html() === undefined
    );
  }

  function getTitelDashboard(title) {
    return title === undefined || title === null || title === ''
      ? $('.headerLogo')
          .children()
          .html()
      : title;
  }

  function buildInfoGrafico(inf) {
    $('.toInfo').each(function(i, label) {
      var $label = $(label);
      var graphLabel = $label.html().replace(/ /g, '');
      var graph = inf.grafico !== null ? inf.grafico.replace(/ /g, '') : null;

      if (graph === graphLabel) {
        var $el = $label.parent();

        $el.attr('id', 'info' + graph);
        $label.append(
          '&nbsp<a style="font-size: 15px;" data-toggle="modal" href=".' +
            graph +
            '"><i class="fa fa-info-circle"></i></a>'
        );
        $el.append(
          buildModal(graph, getTitleGrafico(inf.titulo, $label), inf.mensagem)
        );
      }
    });
  }

  function getTitleGrafico(title, $label) {
    return title === undefined || title === null
      ? (title = $label.html())
      : title;
  }

  function buildModal(clazz, title, msg) {
    return (
      '<div class="modal fade ' +
      clazz +
      '" tabindex="-1" role="dialog" aria-hidden="true" style="text-align: left;"> ' +
      '  <div class="modal-dialog modal-md"> ' +
      '    <div class="modal-content"> ' +
      '      <div class="modal-header"> ' +
      '        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span> ' +
      '        </button> ' +
      '        <h3 class="modal-title" id="myModalLabel2">' +
      title +
      '</h3> ' +
      '      </div> ' +
      '      <div class="modal-body"> ' +
      '          <pre class="modal-pre">' +
      msg +
      '          </pre>' +
      '      </div> ' +
      '      <div class="modal-footer"> ' +
      '        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> ' +
      '      </div> ' +
      '    </div> ' +
      '  </div> ' +
      '</div>'
    );
  }
}

$(function() {
  var custom =
    typeof customDateRangePicker !== 'undefined' ? customDateRangePicker() : {};

  var start =
    custom.start !== undefined ? custom.start : moment().startOf('month');
  var end = custom.end !== undefined ? custom.end : moment();

  var rangeDefault = {
    Hoje: [moment(), moment()],
    Ontem: [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
    'Últimos 7 Dias': [moment().subtract(6, 'days'), moment()],
    'Últimos 30 Dias': [moment().subtract(29, 'days'), moment()],
    'Mês Atual': [moment().startOf('month'), moment().endOf('month')],
    'Mês Passado': [
      moment()
        .subtract(1, 'month')
        .startOf('month'),
      moment()
        .subtract(1, 'month')
        .endOf('month')
    ],
    'Ano Atual': [moment().startOf('year'), moment().endOf('year')]
  };

  setTimeout(function(){
    console.info("loading daterangerpicker - (parDataInicial & parDataFinal) in parDummy Dashboards.fireChange...");

  	Dashboards.setParameter('parDataInicial', start.format('YYYY-MM-DD'));
    Dashboards.setParameter('parDataFinal', end.format('YYYY-MM-DD'));    
    Dashboards.fireChange('parDummy', 1);

  }, 1000);

  $('#daterangepicker').on('apply.daterangepicker', function(ev, picker) {
    Dashboards.setParameter(
      'parDataInicial',
      picker.startDate.format('YYYY-MM-DD')
    );
    Dashboards.setParameter('parDataFinal', picker.endDate.format('YYYY-MM-DD'));
    Dashboards.fireChange('parDummy', 1);
  });

  function cb(start, end) {
    $('#daterangepicker span').html(
      start.format('DD/MM/YYYY') + ' - ' + end.format('DD/MM/YYYY')
    );
  }

  $('#daterangepicker').daterangepicker(
    {
      startDate: start,
      endDate: end,
      ranges: custom.range !== undefined ? custom.range : rangeDefault,
      locale: {
        format: 'DD/MM/YYYY',
        separator: ' - ',
        applyLabel: 'Aplicar',
        cancelLabel: 'Cancelar',
        fromLabel: 'From',
        toLabel: 'To',
        customRangeLabel: 'Informar Data',
        weekLabel: 'W',
        daysOfWeek: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],
        monthNames: [
          'Janeiro',
          'Fevereiro',
          'Março',
          'Abril',
          'Maio',
          'Junho',
          'Julho',
          'Agosto',
          'Setembro',
          'Outubro',
          'Novembro',
          'Dezembro'
        ]
      }
    },
    cb
  );

  cb(start, end);
});

function loadPage(href) {
  var xmlhttp = new XMLHttpRequest();
  xmlhttp.open("GET", href, false);
  xmlhttp.send();
  return xmlhttp.responseText;
};

function setBlinker(el) {
  var count = 0;
  var times = 8*2;
  
  setTimeout(function() {
    var interval = setInterval(function() {
      
      $(el).toggleClass(function() {
        count++;
        return 'blinker';
      });
      
      if (count == times) clearInterval(interval);

    }, 300);
  }, 500);
}


function putLabelon(el, label) {
  if ($(el).has('.selectorLabel').length === 0)
    $(el).prepend('<div class="selectorLabel">' + label + '</div>');
  
    ajustaWidthLabelsFiltros();
}

function puLabel2on(el, label) {
  if ($(el).has('.selectorLabel2').length === 0)
    $(el).prepend(
      '<div><label class="selectorLabel2 toInfo"> ' +
      label +
      ' </label></div>'
    );
}

function qDataCarga(data) {
  referencia = Date.today()
    .add(-2)
    .days();
  str = sprintf(data.resultset[0][0]);

  var dataVerifica = new Date(data.resultset[0][1]);

  if (parCliente != '0')
    if (data.resultset[0][0])
      $('#dataCarga').html('(Atualizado em: ' + str + ')');
    else
      $('#dataCarga').html('(SEM DADOS P/ ESTA ÁREA)');
    
  if (dataVerifica <= referencia)
    setBlinker('.blink');

}

function valueFormatFloat(v) {
  return formata_valor(sprintf('%.1f', v), 'I');
}

function valueFormatFloat2(v) {
  return formata_valor(sprintf('%.2f', v));
}

function valueFormatInt(v) {
  return formata_valor(sprintf('%d', v), 'I');
}

var countAjustaWidth = 1;
$(function() {
  setTimeout(function(){
    countAjustaWidth = 0;
  }, 5000);
});

function ajustaWidthLabelsFiltros() {
  var $maior = $();
  var maior = 0

  $('.selectorObj .selectorLabel').each(function(i, e){
      if ($(e).width() > maior) {
        maior = $(e).width();
        $maior = $(e);
      }
  });

  $maior.width(maior + (countAjustaWidth == 1 ? 1 : 0));
  
  $('.selectorObj .selectorLabel').each(function(i, e){
      $(e).css('width', $maior.css('width'))
  })
}


function openDiologMsg() {
//  $("#msgPainelNaoContratado").dialog("open");
//  $("#msgEmailPainelNaoContratado")
//      .attr('href', `mailto:suporte.ga@ga.agr.br?subject=Acesso à novo painel do BI&body=Solicito acesso ao painel: ${$(this).html()}`);
}

$(function () {

//  $("#msgPainelNaoContratado").dialog({
//      autoOpen: false,
//      modal: true,
//      buttons: {
//          OK: function () {
//              $(this).dialog("close");
//          }
//      }
//  });
});


/**
 * Convert resultset from array of array to array of objects
 * @param {Array} dataset from CDA
 */
function resultsetToObject(dataset) {
  var objects = [];
  $(dataset.resultset).each(function (i, rs) {
      var obj = {};
      $(rs).each(function (j, r) {
          obj[dataset.metadata[j].colName] = r;
      });
      objects.push(obj);
  });
  return objects;
}