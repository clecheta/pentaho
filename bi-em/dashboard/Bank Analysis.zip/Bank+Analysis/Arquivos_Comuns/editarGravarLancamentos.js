var dir = '../../../api/repos/pamenu/resources/app/';
var dirLocal = dir + 'editarGravarLancamentos/';

$(document).ready(function () {
    console.log('inicio_dash_editar_gravar_lancamentos');

});

function tabClickPrincipal(celClic) {

    if (celClic.tableData[celClic.rowIdx][0] > 0) {

        parIdLancamento = celClic.tableData[celClic.rowIdx][0];
        parContabilizado = celClic.tableData[celClic.rowIdx][4];
        parComentario = celClic.tableData[celClic.rowIdx][5];
        parIdTipo = celClic.tableData[celClic.rowIdx][7];
        parIdContrato = celClic.tableData[celClic.rowIdx][8];

        Dashboards.fireChange('parIdLancamento', parIdLancamento);
        Dashboards.fireChange('parContabilizado', parContabilizado);
        Dashboards.fireChange('parComentario', parComentario);
        Dashboards.fireChange('parIdTipo', parIdTipo);
        Dashboards.fireChange('parIdContrato', parIdContrato);
        Dashboards.fireChange( 'parAtualiza', parAtualiza);

        $('#tabs-abas a[href="#detalhe"]').html('Editar Lan&ccedil;amento').tab('show');
    }
}

function customDateRangePicker() {
    return {
        start: moment().subtract(1, 'month').startOf('month'),
        end: moment().subtract(1, 'month').endOf('month'),
        range: {
            'Mês Atual': [moment().startOf('month'), moment().endOf('month')],
            'Mês Anterior': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
            'Ano Atual': [moment().startOf('year'), moment().endOf('year')],
        }
    };
}

function tabelaPrincipalPreExecution($this) {
    $this.chartDefinition.oLanguage = {
        "sProcessing": "Processando...",
        "sLengthMenu": "Mostrar _MENU_",
        "sZeroRecords": "Dados não encontrados para os parâmetros selecionados",
        "sInfo": "Mostrando de _START_ a _END_ de _TOTAL_ registros",
        "sInfoEmpty": "Mostrando de 0 a 0 de 0 registros",
        "sInfoFiltered": "",
        "sInfoPostFix": "",
        "sSearch": "Buscar:",
        "sValue": "Valor:",
        "sUrl": "",
        "oPaginate": {
            "sFirst": "Primeiro",
            "sPrevious": "Anterior",
            "sNext": "Seguinte",
            "sLast": "Último"
        }
    };

    $this.setAddInOptions("colType", "numericBR", function (cell_data) {
        var status = cell_data.value;

        return (status >= 0) ? {
            textFormat: function (v, st) {
                return "<span style='color: blue'>" + v.toLocaleString('pt-br', { minimumFractionDigits: 2 });
            }
        } : {
                textFormat: function (v, st) {
                    return "<span style='color: red'>" + v.toLocaleString('pt-br', { minimumFractionDigits: 2 });
                }
            }
    });
}

function totalizacaoPrincipal(data) {
    var positivo = data.resultset[0][0];
    var negativo = data.resultset[0][1];
    var saldo = data.resultset[0][2];

    $('#totalizacaoPrincipal').html(`<center><big>Totalização: 
    Entrada: R$ <b>${valueFormatFloat2(positivo)}&nbsp;&nbsp;</b> 
    Saída: R$ <b>${valueFormatFloat2(negativo)}&nbsp;&nbsp;</b> 
    Saldo: R$ <b>${valueFormatFloat2(saldo)}</b></big></center>`);
}